// config.js

module.exports = {
    JWT_SECRET: 'deb39826d1cda64a47c1c4f78f4607cc4679e1cf54842e12abdc743b66efef64',
  };
  